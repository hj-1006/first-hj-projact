import requests

#bs4에서 BeautifulSoup만 가저옴
from bs4 import BeautifulSoup

from pathlib import Path
import urllib

#타임 임폴트
import time

#웹 페이지를 구해 해석
load_url = "http://python.cyber.co.kr/pds/books/python2nd/test2.html"
html = requests.get(load_url)
soup = BeautifulSoup(html.content,"html.parser")

#download2 파일 만들기mkdir
o_f = Path('download2')
o_f.mkdir(exist_ok=True)

#모든 이미지 파일을 찾는다.
for element in soup.find_all('img'):
    src = element.get("src")
    
    
    #절대 URL과 파일을 표시한다.
    imge_url = urllib.parse.urljoin(load_url, src)
    imgdata = requests.get(imge_url)

    #마지막에 있는 파일명을 추출하고 저장 폴더명과 연결
    filename = imge_url.split("/")[-1]    
    o_p = o_f.joinpath(filename)
    
    #이미지 데이터 파일에 쓴다
    with open(o_p,mode="wb") as f:
        f.write(imgdata.content)
    
    #한번 엑세스 후 1초 대기
    time.sleep(1)