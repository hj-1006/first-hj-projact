import requests

image_url = "http://python.cyber.co.kr/pds/books/python2nd/sample1.png"
imgdata = requests.get(image_url)

#뒤에있는것sample.png
filename = image_url.split("/")[-1]

with open(filename,mode="wb") as f:
    f.write(imgdata.content)