import requests
#bs4에서 BeautifulSoup만 가저옴
from bs4 import BeautifulSoup


load_url = "http://python.cyber.co.kr/pds/books/python2nd/test2.html"
html = requests.get(load_url)
soup = BeautifulSoup(html.content,"html.parser")


#챕터2만 나옴
chap2 = soup.find(id="chap2")
for element in chap2.find_all("li"):
    print(element.text)