import requests
#bs4에서 BeautifulSoup만 가저옴
from bs4 import BeautifulSoup
#urllib선언
import urllib


load_url = "http://python.cyber.co.kr/pds/books/python2nd/test2.html"
html = requests.get(load_url)
soup = BeautifulSoup(html.content,"html.parser")

for element in soup.find_all("a"):
    print(element.text)
    
    #href 속성에 있는것들
    url = element.get("href")
    
    #urllib으로 링크 선언
    link_url = urllib.parse.urljoin(load_url,url)
    print(link_url)