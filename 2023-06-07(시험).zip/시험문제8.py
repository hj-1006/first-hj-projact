#임폴트 판다스
import pandas as pd


df = pd.read_csv("test.csv",encoding=("cp949"))

#이중대괄호로 국어중 90점 이상
data_s = df[df["국어"]>=90]
print("국어가 90점 이상\n",data_s)

#위와 같음
data_c = df[df["수학"]<70]
print("수학이 70점 미만\n",data_c)
