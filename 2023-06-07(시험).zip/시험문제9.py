import pandas as pd

df = pd.read_csv('test.csv',encoding=('cp949'))

#sort_values로 ascendong=False로 내림차순
kor = df.sort_values("국어",ascending=(False))
print("국어 점수가 높은 순으로 정렬\n",kor)