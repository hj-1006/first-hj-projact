import requests
#bs4에서 BeautifulSoup만 가저옴
from bs4 import BeautifulSoup


load_url = "http://python.cyber.co.kr/pds/books/python2nd/test2.html"
html = requests.get(load_url)
soup = BeautifulSoup(html.content,"html.parser")


#모든 li 테그 검색
for element in soup.find_all("li"):
    print(element.text)