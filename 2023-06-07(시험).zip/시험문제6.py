import requests
#bs4에서 BeautifulSoup만 가저옴
from bs4 import BeautifulSoup
#urllib선언
import urllib


load_url = "http://python.cyber.co.kr/pds/books/python2nd/test2.html"
html = requests.get(load_url)
soup = BeautifulSoup(html.content,"html.parser")

for element in soup.find_all('img'):
    src = element.get("src")
    
    #절대 URL과 파일을 표시한다.
    imge_url = urllib.parse.urljoin(load_url, src)
    filename = imge_url.split("/")[-1]
    #주소 >> 이미지
    print(imge_url, ">>",filename)