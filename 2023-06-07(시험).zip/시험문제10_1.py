import pandas as pd
import openpyxl

#csv파일을 읽어 들인다.
df = pd.read_csv('test.csv',encoding=('cp949'))

#국어 점수로 배열한다.
kor = df.sort_values("국어",ascending=False)

#엑셀파일을 생성한다.
with pd.ExcelWriter("csv_to_excel3.xlsx") as write:
    df.to_excel(write,index=False,sheet_name="원본데이터")
    kor.to_excel(write,index=False,sheet_name="국어로 정렬")