import pandas as pd

#데이터 프레임을 읽는다
df = pd.read_csv("100701_2023053111382264",header=None)

results = df[df[3]=="개포로"]
print(results[[0,1,2,3,4]])

results = df