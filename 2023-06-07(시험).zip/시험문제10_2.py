import pandas as pd
import openpyxl
#시트가 여러 개 있는 경우 
df = pd.read_excel('csv_to_excel3.xlsx')
print(df)
#국어 시트
df = pd.read_excel('csv_to_excel3.xlsx', sheet_name="국어로 정렬")
print(df)