import requests

url = 'http://python.cyber.co.kr/pds/books/python2nd/test1.html'
#requests 불러오기
response = requests.get(url)

response.encoding = response.apparent_encoding

filename = 'download.txt'
#with as
with open(filename, mode = 'w') as f:
    f.write(response.text)